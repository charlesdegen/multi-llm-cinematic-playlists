# CNB consumer onboarding — offline demo

Open `consumer-onboarding-offline.html` for the complete banker → client → Approved KYC journey. `client-portal-offline.html` starts at SMS authentication; `application-offline.html` starts at product selection. Each HTML is standalone: embedded fonts, logos, styles, JavaScript, and captured disclosure text. No server, package installation, or internet connection is required for the demo's runtime.

## Walkthrough

1. In Onboarding Requests, open any of the 12 scenarios or click **Initiate Onboarding**. Select Checking, Savings, or Money Market and one of the four individual/joint client types.
2. **Save & Continue**. Select an existing fictional primary client or **Create Prospect**, then choose the primary relationship type. **Fill primary with sample** is the presentation shortcut. Only primary information is required in Salesforce; joint owners and beneficiaries are entered later in the portal.
3. **Launch NCO Portal Invite** → Primary Party → CNB Point Of Contact → Package Review → **Save & Submit to Client**. This opens an email preview; no message is sent.
4. Click **LOGIN** and confirm the demo phone. The illustrative iPhone 18 overlay rises on the right. Copy the visible code, use the in-page **Paste code** fallback, or select **Use code & continue**. Enter matching demo passwords and continue through Product Requests → **Begin**.
5. Use **Demo controls → Fill this step with sample data**, or enter fictional details. Banker-selected product and client type initialize the portal. Save each applicable beneficiary and joint party. Beneficiary allocations must total 100%.
6. Review Summary and complete the applicable acknowledgments. Scroll each of the four disclosures to its end and accept it. **Submit Application** displays the confirmation and a downloadable synthetic PDF summary.
7. **Continue to Banker Client Review → Run Client Review**. All four LexisNexis checks and all eight FIS IDV checks pass; preliminary risk score is 10, category Low, and Onboarding Decision becomes **Approved**. Joint scenarios include a client selector in the review dialog.
8. **12 scenarios** returns to the request list. Progress remains separate for each case. **Restart this scenario** clears only that case; reloading resets the whole demonstration.

All 12 client/product combinations are supported. Multiple products and multiple people can be added. Previous steps remain accessible. Data exists only in the current tab's memory; reloading clears it. Password fields are cleared after the password step; secret word/hint are cleared at submission. PDF summaries omit tax identifiers, credentials, and contact information.

## Provenance and scope

Captured from the supplied photos and the user's CNB UAT browser on November 3, 2026. The observed live path included checking, a beneficiary, and a joint party. The user completed credential entry, source tax-ID entry, designation attestations, and final UAT submission. Submission confirmation and the dashboard's Submitted status were observed.

The other client branches, savings/money-market completion paths, mobile layouts, additional people/accounts, conditional alternate-address fields, and local validation are demo adaptations of the captured screens. They are not independent verification of every UAT branch or bank policy. Product amounts and disclosure wording reproduce the captured UAT state; they are not current published offers or approved legal advice. Non-US/W-8 workflows, document upload, real identity verification, and account activation are not implemented.

The banker and KYC layouts reproduce the supplied photos. The user explicitly directed primary-only banker collection and all-positive KYC with Approved as the final demo decision. Photos contain rendered results, not API payload schemas; no vendor API contract or approval logic is implied. The joint relationship label is a demo adaptation because its bank relationship code was not supplied.

The iPhone 18 is an illustrative CSS device. SMS, tax validation, address validation, consents, submission, and the PDF are local simulations. The PDF is a synthetic demo receipt, not the bank's downloadable application package. Public privacy, rates, and social links open external sites only when explicitly clicked and require internet. No form or background request sends data; CSP blocks network connections and form submission.

## Validation and limits

- All 12 connected banker/client/product paths exercised through submission and Approved KYC using browser UI. Each produced all 12 positive verification checks.
- Custom primary creation and identity propagation, primary-only invitation gating, independent case progress, scenario restart, and cancel/restore were checked.
- Desktop and 390 px mobile banker/KYC layouts inspected; role-table containment corrected on mobile.
- Required product, unsaved-person, and non-100% allocation gates checked; equal distribution produced 50/50.
- Summary editing, four scroll-gated consents, submitted dashboard, and PDF download exercised.
- Generated PDF parsed successfully with macOS PDFKit: one page, synthetic summary, no credentials or tax IDs.
- Mobile joint-with-beneficiaries path completed at 390 px; address dialog overflow fixed.
- Phone in-page Paste code passed verification against the displayed demo SMS. The browser testing interface uses a separate virtual clipboard and could not verify the operating-system clipboard contents. The UI's Copy code path snapshots the displayed code and provides the same-code in-page fallback.
- Direct `file://` browser testing was blocked by the test interface's protocol policy. The identical packaged HTML was exercised over loopback; embedded assets and absence of network runtime dependencies were checked statically. Double-click opening is supported by construction but was not directly verified in this interface.

Editable sources and private reference captures remain in `screens/`; they are excluded from the portable ZIP. The earlier banker prototype remains in `v1/` as historical work; the connected primary-only version is in `screens/banker/`. The pre-integration source and deliverables are preserved in `versions/before-banker-connection-2026-11-03/`. Build with `python3 screens/sms-authentication/build.py`; package with `python3 package_offline.py`.
